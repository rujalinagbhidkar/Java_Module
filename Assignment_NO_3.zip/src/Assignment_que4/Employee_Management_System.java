package Assignment_que4;

import java.util.*;

interface EmployeeManager{
	void addEmployee(Employee emp);
	void updateDepartment(int empId);
	void removeEmployee(int empId);
	void displayEmployeee();
}

class Employee{
	private String name;
	private int empId;
	private String department;
	
	Employee(String name, int empId, String department){
		this.empId = empId;
		this.name = name;
		this.department = department;
	}
	
	public void setDepartment(String department) {
		this.department = department;
	}
	
	public String getName() {
		return name;
	}
	public int getEmpId() {
		return empId;
	}
	public String getDepartment() {
		return department;
	}
	public String toString() {
		return String.format("EmpId: %-15d Name: %-25s Department: %s", empId, name,department);
	}
}

class EmployeeDatabase implements EmployeeManager{
	List<Employee> employees = new ArrayList<>();
	
	//@Override
	public void addEmployee(Employee emp) {
		employees.add(emp);
		System.out.println("Employee Added ");
	}
	
	//Override
	public void updateDepartment(int empId) {
		Scanner sc = new Scanner(System.in);
		boolean found = false;
		for (Employee e : employees) {
			if (e.getEmpId() == empId) {
				System.out.println("Enter new Department for " + e.getName() + ": ");
				String newDept = sc.nextLine();
				System.out.println("Previous Department: ");
				e.setDepartment(newDept);
				System.out.println("New Department : " + e.getDepartment());
				System.out.println("Department Updated Sucessfully for empId : " + e.getEmpId());
				found = true;
				break;
			}
		}
		if (!found) {
			System.out.println("Employee with id " + empId + "not found.");
		}
	}
	
	//Override
	public void removeEmployee(int empId) {
		boolean isRemoved = false;
		for (int i = 0 ; i < employees.size(); i++) {
			Employee e = employees.get(i);
			if(e.getEmpId() == empId) {
				employees.remove(i);
				isRemoved = true;
				System.out.println("Employee with EmpId " + e.getEmpId() + " is sucessfully Removed");
				break;
			}
		}
		if(!isRemoved) {
			System.out.println("Employee with Id " + empId + " doesn't exixts." );
		}
	}
	
	//Override
	public void displayEmployeee() {
		if (employees.isEmpty()) {
			System.out.println("There are no employees in the database. ");
		}else {
			for(Employee e : employees) {
				System.out.println(e);
			}
		}
	}
}

public class Employee_Management_System {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeManager employee = new EmployeeDatabase();
		
		boolean run = true;
		
		while(run) {
			System.out.println("\n--- Employee Database Management ---");
            System.out.println("1.) Add New Employee\n2.) Update Department\n3.) Remove Employee\n4.) Display All Employees\n5.) Exit");
            System.out.println("Choose: ");
            int choice = sc.nextInt(); sc.nextLine();
            
            switch(choice) {
            case 1 :
            	System.out.print("Employee ID (int): "); int empId = sc.nextInt(); sc.nextLine();
                System.out.print("Employee Name: "); String name = sc.nextLine();
                System.out.print("Employee Department: "); String dept = sc.nextLine();
                employee.addEmployee(new Employee(name, empId, dept));
                break;
            case 2:
                System.out.print("Employee Id to Update Department: "); empId = sc.nextInt(); sc.nextLine();
                employee.updateDepartment(empId);
                break;
            case 3:
                System.out.print("Employee Id to remove: "); empId = sc.nextInt(); sc.nextLine();
                employee.removeEmployee(empId);
                break;
            case 4:
                employee.displayEmployeee();
                break;
            case 5:
                run = false;
                System.out.println("Exited!");
                break;
            default:
                System.out.println("Invalid Input!");           
            }
		}sc.close();
	}
}
